# 二次输入与多轮会话

`ctx.prompt()` 先提问，再等待当前会话中同一用户的下一条消息。

- 支持文字、图片和其他附件。
- 可设置超时和取消词。
- 适用于命令和附件处理器；按钮、原始事件上下文不提供 prompt。

## 使用方式

```ts
import { Command, Controller, Ctx } from 'dou-bot';
import type { MessageContext } from 'dou-bot';

@Controller()
export class DialogController {
  @Command('交互示例')
  async dialog(@Ctx() ctx: MessageContext): Promise<void> {
    const name = await ctx.prompt('请输入角色名，发送“取消”退出：', {
      timeoutMs: 60000,
      cancelWords: ['取消'],
    });
    if (name.status !== 'received') return;

    const server = await name.message.prompt('请输入所在服务器：');
    if (server.status !== 'received') return;

    await server.message.reply(
      `收到角色名：${name.message.content}\n服务器：${server.message.content}`,
    );
  }
}
```

- 每次 prompt 都要 `await`，处理器最后返回 `void`。
- 下一轮使用 `answer.message.prompt()`；回复使用 `answer.message.reply()`，引用最新输入。
- 处理器结束后 Context 失效，不能用于长期任务。

## API 与返回值

| status    | 含义                         | 可用数据                     |
| --------- | ---------------------------- | ---------------------------- |
| received  | 收到输入，包括空文字或仅附件 | message：新的 MessageContext |
| timeout   | 等待超时                     | 无 message                   |
| cancelled | 输入匹配取消词               | 无 message                   |

- 用 `status` 判断结果，不能用正文是否为空判断超时。
- 取消、超时不自动发送提示，由业务决定是否回复。
- 发送失败、重复等待、资源不足或关闭中断会拒绝 Promise。
- 问题接受 `MessageInput`，可使用文字或 Markdown。

## 默认配置

在 `AppFactory.create()` 的 options 中配置：

```ts
prompts: {
  timeoutMs: 60000,
  maxTimeoutMs: 300000,
  maxPending: 1000,
  cancelWords: ['取消'],
}
```

| 字段         | 作用                                           |
| ------------ | ---------------------------------------------- |
| timeoutMs    | 默认每轮等待 60 秒，从提问发送成功后计时       |
| maxTimeoutMs | 每轮最多 5 分钟；若低于 60 秒，默认等待取此值  |
| maxPending   | 最多 1000 个等待项                             |
| cancelWords  | 去除首尾空白后精确匹配，区分大小写；空数组禁用 |

- 单次调用可覆盖 `timeoutMs`、`cancelWords`，不能超过全局最长等待时间。
- 时间必须是正整数且不超过 2147483647ms，取消词不能是空字符串。
- 全局配置错误报 CONFIG，单次参数错误报 HANDLER_CONTRACT。

## 匹配与消费

- 私聊按用户匹配；群聊按群和用户匹配，不会收到其他人的回答。
- 同一会话用户同时只能有一个等待；不同群、私聊互不影响。
- 下一条消息即使是 `/help` 也算回答，不再触发 Command、OnAttachment 或 On。
- 取消词优先识别；超时后的消息按正常规则处理。
- 按钮点击不能作为消息回答。
- Guard 和冷却只在原入口执行，敏感操作需在真正执行前复核权限。
- 群聊无响应时，先 @机器人回复，再检查账号投递权限。

## 并发与关闭

- 等待用户时释放执行并发名额；恢复后仍遵守并发上限。
- 对话仍占用事件、缓存和操作预算，实际容量也受 execution 配置限制。
- 重复投递不会满足下一轮等待。
- 应用关闭会取消等待；重启不会恢复对话，长期结果需另行保存。

## 离线测试

1. `enqueue()` 发起命令。
2. 观察到问题发送记录后，`enqueue()` 投递回答。
3. 多轮对话重复第 2 步，最后等待 `done` 或 `flush()`。

- 不要先等待起始命令的 `dispatch()`，否则无法投递它正在等待的回答。
- 第一轮回答的 `done` 也可能等待整个流程结束；用下一条问题记录判断何时回答。
- 完整示例见 [两轮问答](https://abandon-jw3.github.io/dou-bot/examples/prompt.html)。
